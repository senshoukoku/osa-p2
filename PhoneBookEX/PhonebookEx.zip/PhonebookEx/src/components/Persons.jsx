const Persons = ({ persons, handleDelete }) => (
  <ul>
    {persons.map((person, index) => (
      <li key={index}>
        {person.name}: {person.number} <button onClick={() => handleDelete(person.id, person.name, person.number)}>Delete</button>
      </li>
    ))}
  </ul>
)

export default Persons
